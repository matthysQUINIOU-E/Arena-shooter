import bpy
import json
import mathutils
import os

def vec(v):
    return [float(v[0]), float(v[1]), float(v[2])]

def export_mesh(obj):
    if obj.type != 'MESH':
        return None

    mesh = obj.to_mesh()
    mesh.calc_loop_triangles()

    uv_layer = mesh.uv_layers.active.data if mesh.uv_layers else None

    vertices = []    
    indices = []       
    vertex_map = {}   

    def key(pos, uv):
        return (round(pos.x, 6), round(pos.y, 6), round(pos.z, 6),
                round(uv[0], 6), round(uv[1], 6))

    for tri in mesh.loop_triangles:
        tri_indices = []

        for loop_idx in tri.loops:
            v = mesh.vertices[mesh.loops[loop_idx].vertex_index]
            pos = v.co

            if uv_layer:
                uv = uv_layer[loop_idx].uv[:]  
            else:
                uv = (0.0, 0.0)

            k = key(pos, uv)

            if k in vertex_map:
                idx = vertex_map[k]
            else:
                idx = len(vertices)
                vertex_map[k] = idx
                vertices.append([pos.x, pos.y, pos.z, uv[0], uv[1]])

            tri_indices.append(idx)

        indices.extend(tri_indices)

    obj.to_mesh_clear()

    return {
        "vertices": vertices,
        "indices": indices
    }


    
def get_material_textures(obj):
    result = {}

    if not obj.data.materials:
        return result

    for mat in obj.data.materials:
        if not mat or not mat.use_nodes:
            continue

        nodes = mat.node_tree.nodes
        links = mat.node_tree.links

        principled = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if not principled:
            continue

        def find_image_for_input(input_name):
            if input_name not in principled.inputs:
                return None

            input_socket = principled.inputs[input_name]

            for link in links:
                if link.to_socket == input_socket:
                    from_node = link.from_node

                    if from_node.type == 'TEX_IMAGE' and from_node.image:
                        return from_node.image.name

                    if from_node.type == 'NORMAL_MAP':
                        if "Color" in from_node.inputs:
                            normal_color = from_node.inputs["Color"]
                            for link2 in links:
                                if link2.to_socket == normal_color:
                                    tex_node = link2.from_node
                                    if tex_node.type == 'TEX_IMAGE' and tex_node.image:
                                        return tex_node.image.name

            return None

        result["base_color"] = find_image_for_input("Base Color")
        result["metallic"] = find_image_for_input("Metallic")
        result["roughness"] = find_image_for_input("Roughness")
        result["normal_map"] = find_image_for_input("Normal")
        result["emission"] = find_image_for_input("Emission")

    return result


def export_scene(filepath):
    scene_data = {"objects": []}
    for obj in bpy.context.scene.objects:
        item = {}
        nameSplit = obj.name.split('_')
        item["name"] = nameSplit[1]
        item["hasPhysic"] = 'P' in nameSplit[0]
        item["hasCollider"] = 'C' in nameSplit[0]
        item["type"] = obj.type
        item["position"] = [float(x) for x in obj.matrix_world.to_translation()]
        rot = obj.matrix_world.to_quaternion()
        item["rotation"] = [float(rot.x), float(rot.y), float(rot.z), float(rot.w)]
        item["scale"] = [float(x) for x in obj.matrix_world.to_scale()]
        item["parent"] = obj.parent.name if obj.parent else None
        item["material"] = obj.active_material.name if obj.active_material else None
        item["mesh"] = export_mesh(obj)
        item["textures"] = get_material_textures(obj)
        scene_data["objects"].append(item)

    with open(filepath, "w") as f:
        json.dump(scene_data, f, indent=4)

# Change the path to wherever you want to place the JSON
# output_path = os.path.join("C:/Users/Matthys/Documents/scene_base", "scene_base.json")
output_path = os.path.join("C:/Users/mquiniou/Documents/scene_base", "scene_base.json")
export_scene(output_path)